var lbModuleController = angular.module('wings.mobile.controllers.lb');
lbModuleController.controller('LB_0101', [
		'$scope',
		'$state',
		'$cordovaBarcodeScanner',
		'$ionicModal',
		'WingsRemoteDbService',
		'$ionicPopup',
		function($scope,$state,$cordovaBarcodeScanner,$ionicModal,WingsRemoteDbService,$ionicPopup) {
			var Application = {};
			$scope.defaultCard = false;
			$scope.cardDetail = false;
			$scope.sqlCode ={
					txt:"Select * from sy_users"
			};
			$scope.onchange  = function(item){
				$scope.selectedWorkCard.card = item.work_card_barcode;
				 var card = $scope.selectedWorkCard.card;
				 var item  = card.substring(13,17);
                 var zone  = card.substring(09,13);
                 var order = card.substring(00,09).replace(/^0*/, '');
                 $scope.selectedWorkCard.workOrder = order;
                 $scope.selectedWorkCard.zone = zone;
                 $scope.selectedWorkCard.item = item;
                 if (_.isNull(order) || _.isNull(zone) || _.isNull(item)) {
                     Application.ShowMessage('Error', 'Error in WORK CARD scan, Please re-scan.');
                     $scope.selectedWorkCard.workOrder = '';
                     $scope.selectedWorkCard.zone = '';
                     $scope.selectedWorkCard.item = '';
                     return false;
                 }
                 var builder =  new StoredFuncProcBuilder("Lb_Apps.Do_Time", "SF",
                		 									'i_Div_No',                      '1',
                		 									'i_Action',                      'VALIDATE-LOGON',
                                                            'i_What',                        'WORK-CARD',
                                                            'i_Work_Order_Number',           order,
                                                            'i_Zone_Number',                 zone,
                                                            'i_Item_Number',                 item,
                                                            'o_Employee_Number',             '',
                                                            'o_Employee_Name',               '',
                                                            'o_Employee_Message_Count',      '',
                                                            'o_Labor_Direct_Flag',           '',
                                                            'o_Billable_Indirect_Flag',      '',
                                                            'o_Authorization_Required_Flag', '');
                 var strSql = builder.queryObjectJson();
		        	WingsRemoteDbService.executeFunction(strSql).then(function (dataIn) {
						console.log("[Function Call] " +JSON.stringify(dataIn));
						$scope.authorizedEmployee = true;
						 /*if (!Application.ValidateCard(result)) {
		                     Script.SetItemValue('Data.Card');
		                     Script.SetItemValue('Data.Order');
		                     Script.SetItemValue('Data.Zone');
		                     Script.SetItemValue('Data.Item');
		                     return false;
		                 }*/
					
			        }, function (response) {
			            console.log("ERROR " + response.status +" MESSAGE : "+response.message);
			        });
			};
			$scope.executeAuthorizationEmployee = function () {
				var badge = $scope.activeSupervisor.badgeNumber;
                if (_.isEmpty(badge)) {
                    alert('Error in BADGE scan, Please re-scan.');
                    return false;
                }
                //Script.SuspendMessages(true);
                var builder = new StoredFuncProcBuilder("Lb_Apps.Do_Time", "SF",
                										   'i_Action',             'VALIDATE-LOGON',
                                                           'i_Div_No',             '1',
                										   'i_What',               'EXCESS-AUTHORIZED-BY-BADGE',
                                                           'i_Authorized_By_Badge', badge);
                var strSql = builder.queryObjectJson();
	        	WingsRemoteDbService.executeFunction(strSql).then(function (dataIn) {
					console.log("[Function Call] " +JSON.stringify(dataIn));
					
					 /*if (!Application.ValidateCard(result)) {
	                     Script.SetItemValue('Data.Card');
	                     Script.SetItemValue('Data.Order');
	                     Script.SetItemValue('Data.Zone');
	                     Script.SetItemValue('Data.Item');
	                     return false;
	                 }*/
				
		        }, function (response) {
		            console.log("ERROR " + response.status +" MESSAGE : "+response.message);
		        });
                /*if (!Application.ValidateAuthorization(badge)) {
                    Script.SetItemValue('Data.Authorized_By');
                    return false;
                }*/
			} ;
			$scope.executeQuery = function(sql){
				var strSql =$scope.sqlCode.txt;
				WingsRemoteDbService.executeQuery(strSql).then(function (dataIn) {
					console.log("************dataIn-Login : " +JSON.stringify(dataIn));
					var rows = angular.fromJson(dataIn.rows)
					//console.log("result-Login : " +rows);
					$scope.dataFrom = rows;
					CreateTable('sqlSonuc',dataIn);
		        }, function (response) {
		            console.log("ERROR " + response.status +" MESSAGE : "+response.message);
		        });
		    };
		    $scope.executeSF = function () {
		    	var badge = $scope.activeEmployee.badgeNumber;
	            var myBuilder = new StoredFuncProcBuilder("Lb_Apps.Do_Time", "SF",
										            		'i_Action',                      'VALIDATE-LOGON',
								                            'i_Div_No',						 '1',
								                            'i_What',                        'BADGE',
								                            'i_Badge',                       badge,
								                            'i_Employee_Number',             '',
								                            'o_Employee_Number',             '',
								                            'o_Employee_Name',               '',
								                            'o_Employee_Message_Count',      '',
								                            'o_Labor_Direct_Flag',           '',
								                            'o_Billable_Indirect_Flag',      '',
								                            'o_Authorization_Required_Flag', '');
		            

		            var strSql = myBuilder.queryObjectJson();
		        	WingsRemoteDbService.executeFunction(strSql).then(function (dataIn) {
						console.log("************Execute Function : " +JSON.stringify(dataIn));
						ValidateBadge(dataIn.result);
					
			        }, function (response) {
			            console.log("ERROR " + response.status +" MESSAGE : "+response.message);
			        });
		            

		    };
		    function ValidateBadge (result) {
	            $scope.activeEmployee.name = result[0].o_Employee_Name;
	            $scope.activeEmployeeName = true;
	            $scope.cardDetail = true;
	           /* if (!IsNull(error) || !IsNull(result.Error)) {
	                Application.ShowMessage('Error', new String(error.Text||result.Error));
	                return false;
	            }*/
	            Application.LaborDirectFlag      = result[0].o_Labor_Direct_Flag;
	            Application.BillableIndirectFlag = result[0].o_Billable_Indirect_Flag;
	            var messageCount                 = result[0].o_Employee_Message_Count;
	            if (messageCount > 0) {
	                /*var window = Script.CreateWindow('', '', -1, -1, -1, -1);
	                window.AddListener(Application.ContinueValidateBadge,'CLOSE');
	                window.Employee_Number   = result.o_Employee_Number;
	                window.Caller_Program_Id = 'LB_0100';
	                window.ShowDialog('/Wings/programs/sy/SY_0013/SY_0013.jsp');*/
	            	alert("Message Count:"+messageCount);
	            }
	            else {
	                return ContinueValidateBadge();
	            }
	        };
	        $scope.showConfirm = function(message) {
	        	   var confirmPopup = $ionicPopup.confirm({
	        	     title: 'Confirm',
	        	     template: message
	        	   });
	        	   confirmPopup.then(function(res) {
	        	     if(res) {
	        	       //console.log('You are sure');
	        	    	 return true;
	        	     } else {
	        	       console.log('You are not sure');
	        	       return false;
	        	     }
	        	   });
	        	 };
	        function ContinueValidateBadge () {
	            if (Application.LaborDirectFlag == 'Y') {
	                ActivateCard();
	            } else if (Application.BillableIndirectFlag == 'Y') {
	                if ($scope.showConfirm('Do you want to Logon to a WORK CARD ?')) {
	                    ActivateCard();
	                } else { 
	                    return Logon();
	                }
	            } else {
	                return Logon();
	            }
	            return true;
	        };
	        function ActivateCard () {
	        	var defaultCardCount;
	        	var sql =" Select Count(0) Default_Card_Count "+
		                " From Pr_Generic_Cards"+
		                " Where Div_No            = 1"+
		                "  And Work_Order_Type   Is Null"+
		                "  And Work_Order_Number Is Not Null"+
		                "  And Active            = 'Y'";
				WingsRemoteDbService.executeQuery(sql).then(function (dataIn) {
					console.log("************dataIn-defaultCardCount : " +JSON.stringify(dataIn.rows));
					var rows = angular.fromJson(dataIn.rows);
					defaultCardCount = rows[0].default_card_count;
	            if (defaultCardCount > 0) {
	            	 var myBuilder2 = new StoredFuncProcBuilder("Sy_Database.Environment", "SF");
			            myBuilder2.addInputParameter("i_Div_No", "1")
			                    .addInputParameter("i_Symbol", "DEFAULT_CARD_DISPLAY");
			            var strSql2 = myBuilder2.queryObjectJson();
			        	WingsRemoteDbService.executeFunction(strSql2).then(function (dataIn2) {
							console.log("************dataIn2-Login : " +JSON.stringify(dataIn2));
			        		 Application.defaultCardDisplay = dataIn2.result[0][""];
	                if (Application.defaultCardDisplay == 'ALWAYS' || Application.defaultCardDisplay == 'FIRST-LOGON') {
	                	if (Application.defaultCardDisplay == 'ALWAYS') {
	                       $scope.defaultCard = true;
	                    }
	                    if (Application.defaultCardDisplay == 'FIRST-LOGON') {
	                        var myBuilder3 = new StoredFuncProcBuilder("Lb_Service.Get_Employee", "SF");
			                myBuilder3.addInputParameter("i_Badge", $scope.activeEmployee.badgeNumber)
	                            .addInputParameter("i_Div_No", "1")
			                    .addOutputParameter("o_Number")
		                        .addOutputParameter("o_Name")
		                        .addOutputParameter("o_Day_Clock_In");
			               var strSql3 = myBuilder3.queryObjectJson();
			        	   WingsRemoteDbService.executeFunction(strSql3).then(function (dataIn3) {
			        		   var employee = dataIn3.result[0];
							   console.log("************Execute Function : " +JSON.stringify(dataIn));
				        }, function (response) {
				            console.log("ERROR " + response.status +" MESSAGE : "+response.message);
				        });
	                        if (employee.o_Day_Clock_In == null) {
	 	                       $scope.defaultCard = true;
	                        }
	                    }
	                }
			        	}, function (response) {
				            console.log("ERROR " + response.status +" MESSAGE : "+response.message);
				        }).then (
				        		
				        		listWorkCards()
				        
				        
				        
				        );;
	            }
				}, function (response) {
		            console.log("ERROR " + response.status +" MESSAGE : "+response.message);
		        });
				
	        };
	        function listWorkCards () {
	        	var cardSql = "Select Distinct "+
                "       LPad(c.Work_Order_Number||c.Zone_Number||c.Item_Number,17,'0') Work_Card_Barcode, /*1*/                           "+
                "       c.Project_Number||'/'||c.Work_Order_Number||'-'||c.Item_Number||'<br/>'||c.Work_Order_Type Column1, /*2*/ "+
                "       Gn_Service.To_Character(c.Open_Date) ||'<br/>'|| c.Wip_Status||'-'|| c.Wip_Reason Column2, /*3*/"+
                "       InitCap(Replace(Description,Chr(10),'<br>')) Description "+
                "  From Lb_Employees            a, "+
                "       Lb_Employee_Assignments b, "+
                "       Pr_Work_Cards_v         c  "+
                " Where a.Div_No           = 1        "+
                "   And a.Badge            = '"+$scope.activeEmployee.badgeNumber+"'  "+
                "   And b.Div_No           = a.Div_No        "+
                "   And b.Employee_Number  = a.Employee_Number "+
                "   And b.Work_Date       <= Trunc(SysDate) "+
                "   And c.Id               = b.Work_Card_Id "+
                "   And c.Status           = 'WIP'";
							
				WingsRemoteDbService.executeQuery(cardSql).then(function (dataIn) {
					console.log("************dataIn-cardSql : " +JSON.stringify(dataIn.rows));
					var rows = angular.fromJson(dataIn.rows);
					$scope.defaultWorkcards = angular.copy(rows);
					$scope.listShow = true;
				});
	        };
			 $ionicModal.fromTemplateUrl('employeeMessagesModal.html', {
			        scope: $scope,
			        animation: 'slide-in-up'
			      }).then(function(modal) {
			        $scope.modal = modal;
			      });  
		     

			$scope.scanBarcode = function () {
				$cordovaBarcodeScanner
			      .scan()
			      .then(function(barcodeData) {
			    	  barcodeData.text = barcodeData.text.replace("*","");
			    	  $scope.activeEmployee.badgeNumber = barcodeData.text;
			        // Success! Barcode data is here
			      }, function(error) {
			        // An error occurred
			      });

			};
			$scope.selectWorkCard = function (item) {
				$scope.selectedWorkCard = angular.copy(item);
				$scope.Message ='SUCCESS';
				console.log('Selected Item: '+$scope.selectedWorkCard.workcardNumber);
				$scope.modal.show();
			};
			$scope.activeEmployee = {
					badgeNumber : '',
					name : '',
					surname: ''
			};
			$scope.activeSupervisor = {
					badgeNumber : '',
					name : '',
					surname: ''
			};
			$scope.employeeMessages = [
					{
						messageId:1,time:'',sender:'wings@',messageHeader:'message1',messageBody:'11111111',isRead:false
					},
					{
						messageId:2,time:'',sender:'wings@',messageHeader:'message2',messageBody:'22222222',isRead:false
					}
					
			];
			$scope.employeeAssignWorkcards = [
			        {
			        	workcardNumber:'10501.1',date:'',description:'',supervisorRequired:true
			        },    
			        {
			        	workcardNumber:'10501.2',date:'',description:'',supervisorRequired:false
			        }  
		    ];
			$scope.selectedWorkCard ={};
			
			$scope.defaultWorkcards;
			

		} ]);