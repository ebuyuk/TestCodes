angular.module('WingsMobileStarter').controller('MenuCtrl', [
		'$scope',
		'WingsGlobalManager',
		'$location',
		'$ionicPopover',
		'WingsRemoteDbService',
		'WingsSessionManager',
		'$ionicHistory',
		'$timeout',
		//START_CONTROLLER
		function($scope,WingsGlobalManager,$location,$ionicPopover,WingsRemoteDbService,WingsSessionManager,$ionicHistory,$timeout) {
			console.log("+++++++++++++++++++++++++++++++ECLIPSE : MenuCtrl++++++++++++++++++++++++++++++++++CONTROLLER");
			//ROLE PROGRAM FETCH
			/*
			$scope.fetchRolePrograms = function (roleId){
				WingsRemoteDbService.fetchRolePrograms(roleId).then(function (dataInMenu) {
					//console.log("ROLE PROGRAMS:*** "+JSON.stringify(dataInMenu));
					WingsSessionManager.resetRoleProgram();
					var jsonObj = JSON.parse(dataInMenu.rows);
					var arrayLength = jsonObj.length;
					
					for (var i = 0; i < arrayLength; i++) {
						WingsSessionManager.addProgram(new MenuItem(jsonObj[i].title,jsonObj[i].program_id,jsonObj[i].program_name,jsonObj[i].lvl));
							 //WingsSessionManager.addRole(new RoleItem(jsonObj[i].role_id,jsonObj[i].description));
					}
					WingsGlobalManager.SetRolePrograms(WingsSessionManager.getPrograms());
				  }, function (error) {
			           // console.log("ERROR " + error.status +" MESSAGE : "+error.message);
			            //response = { success: false, message: 'Username or password is incorrect' };
			            //callback(response);
			      });
			};
			*/
			//ROLE PROGRAM FETCH
			
			$scope.signOut = function() {
				WingsGlobalManager.ClearCredentials();
				// $state.go('tab.home');
				  $scope.closePopover ();
				  $ionicHistory.clearCache();
				
				
				$timeout(function() {
				    $ionicHistory.clearCache();
				    $ionicHistory.clearHistory();
				}, 100);
				/*
				$timeout(function() {
					$location.path('/');
				}, 200);*/
				
				
				 $state.go('signin');

			};
			
			// POP OVER
			// .fromTemplate() method

			  // .fromTemplateUrl() method
			  $ionicPopover.fromTemplateUrl('my-popover.html', {
			    scope: $scope
			  }).then(function(popover) {
			    $scope.popover = popover;
			  });


			  $scope.openPopover = function($event) {
			    $scope.popover.show($event);
			  };
			  $scope.closePopover = function() {
			    $scope.popover.hide();
			  };
			  //Cleanup the popover when we're done with it!
			  $scope.$on('$destroy', function() {
			    $scope.popover.remove();
			  });
			  // Execute action on hide popover
			  $scope.$on('popover.hidden', function() {
			    // Execute action
			  });
			  // Execute action on remove popover
			  $scope.$on('popover.removed', function() {
			    // Execute action
			  });
		} 
		//END_CONTROLLER
		])