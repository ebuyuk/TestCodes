var lbModuleController = angular.module('wings.mobile.controllers.lb');
lbModuleController.controller('LB_0051', [ '$scope', '$state',
		function($scope, $state) {
			$scope.test = function() {
				alert(1);
			};
		} ]);