var homeController = angular.module('wings.mobile.controllers.lb',[]);
