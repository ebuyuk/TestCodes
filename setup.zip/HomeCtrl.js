angular.module('WingsMobileStarter').controller('HomeCtrl', [
		'$scope',
		'WingsSessionManager',
		'$state',
		//START_CONTROLLER
		function($scope,WingsSessionManager,$state) {
			
			console.log("+++++++++++++++++++++++++++++++ECLIPSE : HomeCtrl++++++++++++++++++++++++++++++++++CONTROLLER");
			
			$scope.applications= [];
			
			$scope.roles = WingsSessionManager.getRoles();
			
			/*$scope.$on('$ionicView.beforeEnter', function() {
			    
			    alert("$scope.menus : "+$scope.menus.length);
			   });*/
			/*$scope.loadImages = function() {
		    	var arr  = WingsSessionManager.leftMenuItems();
		    	console.log('****arr.length*******'+arr.length);
		        for(var i = 0; i < arr.length; i++) {
		            $scope.applications.push({id: i, src: "http://placehold.it/50x50",title : arr[i].title});
		            this.title = title.replace(regex, "");
		      	  this.program_id = program_id;
		      	  this.action = action;
		      	  this.menulevel = menulevel;
		        	//$scope.images.push({id: i, src: "img/applications/64x64/"+i+".png"});
		        }
		    }*/
			$scope.allStates = function() {
		    	console.log(angular.toJson($state.get()));
		    	$state.go('app.LB_0100');
		    }

		} 
		//END_CONTROLLER
		])