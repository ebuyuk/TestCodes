export default class MonitoringCapture {
    constructor(fields: any);
}
