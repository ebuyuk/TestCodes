declare const assign: (target: any, ...objs: any[]) => any;
export { assign };
