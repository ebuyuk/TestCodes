declare const reportMetric: (key: string, value: number) => void;
declare const startMetrics: () => void;
export { startMetrics, reportMetric };
