import { Pro } from './index';
/**
 * Auto-initialize pro based on a script tag and data- attrs.
 * This is the original behavior back-ported for compat.
 */
declare const bootstrapCDN: () => Pro;
export { bootstrapCDN };
