angular.module('WingsMobileStarter').controller('SY_M001', [
        '$scope','WingsSetupDBService','WingsTransactionDBService','WingsDialogService','WingsRemoteDbService',
        function($scope,WingsSetupDBService,WingsTransactionDBService,WingsDialogService,WingsRemoteDbService) {

        } 
])